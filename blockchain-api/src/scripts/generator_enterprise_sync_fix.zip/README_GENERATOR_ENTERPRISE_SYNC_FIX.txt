Generator Enterprise Sync Fix
=============================

Updated files:
1. generate-wallets-transactions-fast.js
2. generate-wallets-transactions.js

What changed:
- Generate Wallets now uses enterprisePersistenceRepository.saveWalletEnterprise().
- Generated wallets are saved into:
  - blockchain.wallets
  - sdedba.ref_customer
  - sdedba.cfg_customer_def
- Generated wallet customer IDs now come from sdedba.s_customer using enterprisePersistenceRepository.getNextCustomerId().
- Generate Transactions now uses enterprisePersistenceRepository.saveTransactionEnterprise().
- Generated transactions are saved into:
  - blockchain.transactions
  - findba.fin_transaction
  - suitedba.cfg_object_api_def
- Wallet balances are still updated after generated transactions.

Important note:
- Because the generator now saves to enterprise/KYC tables too, performance will be slower than the previous pure blockchain-table batch insert.
- This is expected because every generated row now has cross-schema persistence.

Recommended quick test:
node src/scripts/generate-wallets-transactions-fast.js --wallets 5 --transactions 10 --batchSize 5 --logEvery 5

Validation SQL:
SELECT COUNT(*) FROM blockchain.wallets WHERE request_source IN ('DATA_GENERATOR','DATA_GENERATOR_FAST');
SELECT COUNT(*) FROM sdedba.ref_customer WHERE comments ILIKE '%Blockchain wallet created%';
SELECT COUNT(*) FROM sdedba.cfg_customer_def WHERE object_content->>'source' = 'BLOCKCHAIN_WALLET';
SELECT COUNT(*) FROM blockchain.transactions WHERE request_source IN ('DATA_GENERATOR','DATA_GENERATOR_FAST');
SELECT COUNT(*) FROM findba.fin_transaction WHERE comments ILIKE '%Blockchain Fabric TX%';
SELECT COUNT(*) FROM suitedba.cfg_object_api_def WHERE api_content->>'source' = 'BLOCKCHAIN_TRANSACTION';
